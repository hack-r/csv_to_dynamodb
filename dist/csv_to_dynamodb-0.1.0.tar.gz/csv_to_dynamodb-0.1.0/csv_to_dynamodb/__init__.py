from .csv_to_dynamodb import create_table

